﻿Public Class frmClientes
    Private Sub btn_confirmaP_Click(sender As Object, e As EventArgs) Handles btn_confirmaP.Click
        Try
            Dim sql = "SELECT * FROM Clientes WHERE cpf='" & txt_CPFC.Text & "'"
            rs = db.Execute(sql)

            If rs.EOF = True Then
                sql = "INSERT INTO Clientes (cpf, nome, data_nascimento, desde) VALUES ('" & txt_CPFC.Text & "', '" & txt_NomeC.Text & "', " &
                                                                                        "'" & data_C.Value.Date & "', '" & Now.Date & "')"
                rs = db.Execute(sql)
                MsgBox("Cliente cadastrado com sucesso!", MsgBoxStyle.Information, "Aviso")
                Me.Close()
            Else
                MsgBox("Esse cliente já está cadastrado no banco de clientes!", MsgBoxStyle.Exclamation, "Aviso")
                Me.Close()
            End If
        Catch ex As Exception
            MsgBox("Erro no formuário Clientes. Contate o administrador!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
        End Try
    End Sub
End Class